import java.util.Random;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int capacidade = 10;
		int[] numeros = new int[capacidade];
		int[] ordenado = new int[capacidade];
		
		
		numeros = Random(numeros);
		print(numeros);
		/*
		minHeap heap = new minHeap(capacidade);
		inserirHeap(heap,numeros);
		System.out.println();
		//print(heap.itens);
		System.out.println();
		heapSort(heap,ordenado);
		print(ordenado);
		
		System.out.println("\n\nCounting sort");
		print(numeros);
		CountingSort c = new CountingSort();
		c.sort(numeros);
		
		print(numeros);
		
		*/
		System.out.println("Por fim com Merge sort");
		numeros = mergeSort.merge(numeros);
		print(numeros);

	}

	private static void heapSort(minHeap heap, int[] ordenado) {
		for (int i = 0; i < ordenado.length; i++) {
			ordenado[i] = heap.extrair();
		}
		
	}

	private static void inserirHeap(minHeap heap, int[] numeros) {
		for (int i = 0; i < numeros.length; i++) {
			heap.inserir(numeros[i]);
		}
		
	}

	private static void print(int[] numeros) {
		System.out.println();
		for (int i = 0; i < numeros.length; i++) {
			System.out.print(numeros[i]+" ");
		}
		
		System.out.println();
		
	}

	private static int[] Random(int[] numeros) {
		// TODO Auto-generated method stub
		Random gerador = new Random();	
		for (int i = 0; i < numeros.length; i++) {
			numeros[i] = gerador.nextInt(250);
		}
		return numeros;
	}

}
