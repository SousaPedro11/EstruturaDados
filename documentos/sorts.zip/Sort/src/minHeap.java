import java.awt.event.ItemEvent;

public class minHeap {
	
	int[] itens;
	int tamanho;
	int capacidade;
	
	public minHeap(int capacidade) {		
		this.capacidade = capacidade;
		this.itens = new int[capacidade];
	}
	
	// pego o indice
	private int getIndicePai(int indiceFilho) { return (indiceFilho-1)/2;}
	private int getIndiceEsq(int indice) { return indice*2+1;}
	private int getIndiceDir(int indice) { return indice*2+2;}
	
	// vejo se existe
	private boolean temPai(int indiceFilho){ return getIndicePai(indiceFilho) >= 0;}
	private boolean temFilhoEsq(int indice){ return getIndiceEsq(indice) < tamanho ;}
	private boolean temFilhoDir(int indice){ return getIndiceDir(indice) < tamanho ;}
	
	// pego o valor
	private int pai(int indiceFilho){ return itens[getIndicePai(indiceFilho)]; }
	private int filhoEsq(int indice){ return itens[getIndiceEsq(indice)]; }
	private int filhoDir(int indice){ return itens[getIndiceDir(indice)]; }
	
	
	void troca(int indice1, int indice2){
		int temp;
		temp = itens[indice1];
		itens[indice1] = itens[indice2];
		itens[indice2] = temp;
	}
	
	
	public void inserir(int item){
		itens[tamanho] = item;
		tamanho ++;
		heapifyUp();
	}

	private void heapifyUp() {
		
		int iSubindo = tamanho - 1;
		// subindo at� ra�s ou encontrar um pai menor
		while(temPai(iSubindo) && itens[iSubindo] < pai(iSubindo)){
			troca(iSubindo, getIndicePai(iSubindo));
			iSubindo = getIndicePai(iSubindo);
		}
		
	}
	
	
	public int extrair(){
		if(tamanho == 0) return -1;
		int item = itens[0];
		itens[0] = itens[tamanho-1];
		tamanho--;
		heapifyDown();
		return item;
		
	}

	private void heapifyDown() {
		
		int iDescendo = 0;
		// vou descer at� chegar em uma folha ou ter dois filhos maiores
		while(temFilhoEsq(iDescendo)){
			// Vou supor que o filho da esquerda � o menor filho
			int menorFilhoIndice = getIndiceEsq(iDescendo);
			// ver se o filho da direita � o menor
			if(temFilhoDir(iDescendo) && filhoDir(iDescendo) < filhoEsq(iDescendo) ){
				menorFilhoIndice = getIndiceDir(iDescendo);
			}
			
			if(itens[iDescendo] < itens[menorFilhoIndice] ){
				break;
			} else{
				
				troca(iDescendo,menorFilhoIndice);
				iDescendo = menorFilhoIndice;
			}
		}
		
	}
	

	
	
	
	
	

}
















