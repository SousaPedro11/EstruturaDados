
public class CountingSort {
	
	 void sort(int arr[])
	    {
	        int n = arr.length;
	        int maiorElemento = 250;
	 
	        // The output character array that will have sorted arr
	        int C[] = new int[n];
	 
	        // Create a count array to store count of inidividul
	        // zera todas posi��es
	        int B[] = new int[maiorElemento];
	        for (int i=0; i<maiorElemento; ++i)
	            B[i] = 0;
	        System.out.println("B parte 1");
	        print(B);
	        // store count of each character
	        for (int i=0; i<n; ++i)
	            B[arr[i]]++;
	        
	        System.out.println("B parte 2");
	        print(B);
	 
	        // Change count[i] so that count[i] now contains actual
	        // position of this character in output array
	        for (int i=1; i<maiorElemento; ++i)
	            B[i] += B[i-1];
	        System.out.println("B parte 3");
	        print(B);
	 
	        // Build the output character array
	        for (int i = 0; i<n; ++i)
	        {
	            C[B[arr[i]]-1] = arr[i];
	            --B[arr[i]];
	        }
	 
	        // Copy the output array to arr, so that arr now
	        // contains sorted characters
	        for (int i = 0; i<n; ++i)
	            arr[i] = C[i];
	    }
	 
		private static void print(int[] numeros) {
			System.out.println();
			for (int i = 0; i < numeros.length; i++) {
				System.out.print(numeros[i]+" ");
			}
			System.out.println();
			
		}
}
