
public class mergeSort {
	
	static int[] merge(int[] A){
        int p = 0;
        int r = A.length - 1;
        mergeSort( A,  p,  r);
        return A;
    }

    static void merge(int[] A, int p, int q, int r) {
        int[] aux = new int[r - p + 1];
        int a = p;
        int b = q + 1;
        int h = 0;
        
        System.out.println("Array da esquerda");
        print(A, p, q);
        System.out.println("Array da direita");
        print(A, q+1, r);
        
        while (a <= q && b <= r) {
            if (A[a] < A[b]) {
                aux[h++] = A[a++];
            } else {
                aux[h++] = A[b++];
            }
        }
        
        while (a <= q) {
        	System.out.println("Vou completar com o vetor da esquerda");
            aux[h++] = A[a++];
        }
        while (b <= r) {
        	System.out.println("Vou completar com o vetor da direita");
            aux[h++] = A[b++];
        }
        for (h = 0; h < aux.length; h++) {
            A[p++] = aux[h];
        }
         System.out.println("Resultante:");
         print(aux,0,aux.length-1);
    }

    private static void print(int[] a, int p, int q) {
    	
		for (int i = p; i <= q; i++) {
			System.out.print(a[i]+" ");
		}
		System.out.println();
		System.out.println();
		
	}

	static void mergeSort(int[] A, int p, int r) {
        int q = (p + r) / 2;
        if (p < r) {
            mergeSort(A, p, q);
            mergeSort(A, q + 1, r);
            merge(A, p, q, r);
        }
    }
    


}
